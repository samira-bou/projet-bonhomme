#include <iostream>
#include <cmath>
using namespace std;
#include "graphics.h"

//-------------------	
//  Question   1   |
//________________/
class fenetre{
	int x;
	int y;
	public:
	void ouvrir_graphique(void);
	void fermer_graphique(void);
	int get_couleur_fond(void);
	int get_x_max(void);
	int get_y_max(void);
	int get_couleur(int x,int y);
	void allume(int x,int y,int c);
	int get_x_min(void);
	int get_y_min(void);
};
//------------------	
//  Suite (MAIN)   |
//________________/

//Methodes de la classe FENETRE

void fenetre::ouvrir_graphique(void){
	initwindow(700,700);
}
void fenetre::fermer_graphique(void){
	closegraph(-1);
}
int fenetre::get_couleur_fond(void){
	return getbkcolor();
}
int fenetre::get_x_max(void){
 return	getmaxx();
}
int fenetre::get_y_max(void){
	return getmaxy();
}
int fenetre::get_couleur(int x,int y){
	return getpixel(x,y);
}
void fenetre::allume(int x,int y,int c){
	 putpixel(x,y,c);
}

//-------------------	
//  Question 2.1   |
//________________/


class figure{
	public:
	int x,y,a,b,c,type;
	
	
	figure(int xx,int yy,int aa,int bb,int cc){
		x=xx;
		y=yy;
		a=aa;
		b=bb;
		c=cc;
	}
	
	public:
	void set_droite(int x,int y,int a,int b,int c);
	void set_cercle(int x,int y,int a,int c);
	void set_croix(int x,int y,int a,int b,int c);
	void set_triangle(int x,int y,int a,int b,int c);
	void set_rectangle(int x,int y,int a,int b,int c);
	int get_couleur();
	int get_x_centre();
	int get_y_centre();
	void dessiner();
	void deplacer(int dx,int dy);
};
//Methodes de la classe FIGURE 
//-------------------	
//  Question 2.2  |
//________________/

void figure::set_droite(int x,int y,int a,int b,int c){
	setcolor(c);
	if (b==0 && a>0)
		type=1;
	else if(b>0 && a==0)
		type=2;
	else if(a>0 && b!=0) 
		type=3;
}
void figure::set_cercle(int x,int y,int a,int c){
	setcolor(c);
	if(a>0)
		type=4;
}
void figure::set_croix(int x,int y,int a,int b,int c){
	setcolor(c);
	if(a>0 && b>0) 
		type=6;
}
void figure::set_triangle(int x,int y,int a,int b,int c ){
	setcolor(c);
 	if(a>0 && b>0) 
		type=7;
}
void figure::set_rectangle(int x,int y,int a,int b,int c){
	setcolor(c);
	if(a>0 && b>0)
		type=5;
}

//-------------------	
//  Question 2.3   |
//________________/


int figure::get_couleur(){
	return c;
}
int figure::get_x_centre(){
	if (type==5 || type==6 || type==1 || type==3 || type==7)
		return x+a/2;
	else if (type==4 || type==2 )
		return x;
	
	
}
int figure::get_y_centre(){
	if (type==5 || type==6|| type==2 || type==3)
		return y+b/2;
	else if (type==7)
		return y+2*b/3;
    else if(type==4 || type==1 )
        return y;
}

//-------------------	
//  Question 2.4  |
//________________/

void  figure::dessiner(){
	
	if (type==1)
		line(x,y,x+a,y);
	else if(type==2)
		line(x,y,x,y+b);
	else if(type==3)
		line(x,y,x+a,y+b);
	else if(type==4)
	    circle(x,y,a/2);
	else if (type==5)
		rectangle(x,y,x+a,y+b);
	else if(type==6){
		line(x,y,x+a,y+b);
		line(x,y+b,x+a,y);
		
	}
	else if(type==7){
		line(x,y,x+a/2,y-b);
  		line(x,y,x+a,y);
		line(x+a/2,y-b,x+a,y);   
	}
	
}
//-------------------	
//  Question 2.5  |
//________________/

void figure::deplacer(int dx,int dy){
	setcolor(0);
	dessiner();
	x=x+dx;
	y=y+dy;
	setcolor(get_couleur());
	dessiner();
}

//-------------------	
//  Question 2.7   |
//________________/

class dessin{
	public:
	int n;
	figure figures[];
	
	dessin(int nn, figure fgrs[]){
		n=nn;
		for(int i=0;i<n;i++)
			figures[i]=fgrs[i];
	}
	
	public:
		void dessiner();
		void deplacer(int dx,int dy);

};

void dessin::dessiner(){
	for(int i=0;i<n;i++){
		setcolor(figures[i].get_couleur());
		figures[i].dessiner();
	}
		
}
//-------------------	
//  Question 2.8   |
//________________/

void dessin::deplacer(int dx,int dy){
	for(int i=0;i<n;i++)
		figures[i].deplacer(dx,dy);
}

// CODE PRINCIPAL

int main(int argc, char** argv) {
	
//------------------------	
//  Question 1 (Suite)   |
//______________________/

	fenetre f; 
	int x,y;
	f.ouvrir_graphique();
 	x=f.get_x_max()/2; 
 	y=f.get_y_max()/2; 
 	f.allume(x,y,f.get_couleur_fond()); 
 	delay(500);
	f.fermer_graphique();
//___________________________________

	f.ouvrir_graphique();
	cout<<f.get_x_max()<<endl;
	f.allume(10,10,3);
	cout<<f.get_couleur(10,10)<<endl;
	
	
	
	
	
//-------------------	
//  Question 2.6   |
//________________/
	//Jambe G
	figure jambeG(75,145,0,50,5);
	//jambe D
	figure jambeD(95,145,0,50,5);
	//Bras G
	figure brasG(10,100,50,-25,5);
	//Bras D
	figure brasD(110,75,50,25,5);	
	
	jambeG.set_droite(jambeG.x,jambeG.y,jambeG.a,jambeG.b,jambeG.c);
	jambeD.set_droite(jambeD.x,jambeD.y,jambeD.a,jambeD.b,jambeD.c);
	brasG.set_droite(brasG.x,brasG.y,brasG.a,brasG.b,brasG.c);
	brasD.set_droite(brasD.x,brasD.y,brasD.a,brasD.b,brasD.c);
	
	jambeG.dessiner();
	jambeD.dessiner();	
	brasG.dessiner();
	brasD.dessiner();
	
	figure cercle1(85,40,50,0,4);
    cercle1.set_cercle(cercle1.x,cercle1.y,cercle1.a,cercle1.c);
    cercle1.dessiner();
	
	figure r(60,65,50,80,9);
	r.set_rectangle(r.x,r.y,r.a,r.b,r.c);
	r.dessiner();
	
	cleardevice();
    figure bh[6] = {jambeG, jambeD, brasG, brasD, cercle1, r};
    dessin bonhomme(6,bh);
    bonhomme.dessiner();
    delay(1000);
    bonhomme.deplacer(450,250);
	delay(500);
//-------------------	
//  Question 2.9   |
//________________/
	
	double nvX, nvY, angle;
    double rayon = f.get_y_max()/2-150;
    nvX = rayon;
    nvY= 0.0;


    for (int i = 0; i < 360; i++) {
        int oldX=nvX,oldY=nvY;
        // M_PI = PI de cmath.h
        angle = i * M_PI / 180.0;
        nvX = int(rayon * cos(angle));
        nvY= int(rayon* sin(angle));
        bonhomme.deplacer(nvX-oldX,nvY-oldY);
        
        delay(20);
    }
	
	delay(500);
	f.fermer_graphique();
	//cin.ignore();
	
	return 0;
}
